﻿using Microsoft.AspNetCore.Mvc;
using TradeCaptureWebAPI.Interface;
using TradeCaptureWebAPI.Models;

namespace TradeCaptureWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SecuritiesController : ControllerBase
    {
        private readonly TradeCaptureContext _context;

        public SecuritiesController(TradeCaptureContext context)
        {
            _context = context;
        }

        [HttpGet("Get-By-Sid/{Sid}")]
        public async Task<ActionResult<Security>> GetSecurity(int Sid)
        {
            if (_context.Security == null)
            {
                return NotFound();
            }
            var security = await _context.Security.FindAsync(Sid);

            if (security == null)
            {
                return NotFound();
            }
            return security;
        }

        [HttpPut("Update-By-Sid/{Sid}")]
        public async Task<IActionResult> PutSecurity(int Sid, [FromBody] Security security)
        {
            var existingSecurity = _context.Security.Where(s => s.Sid == Sid)
                                                   .FirstOrDefault<Security>();

            if (existingSecurity != null)
            {
                existingSecurity.TypeId = security.TypeId;
                existingSecurity.Name = security.Name;
                existingSecurity.StartDate = security.StartDate;
                existingSecurity.EndDate = security.EndDate;
                existingSecurity.Ticker = security.Ticker;
                existingSecurity.ExchangeId = security.ExchangeId;
                existingSecurity.CurrencyId = security.CurrencyId;
                existingSecurity.UnderlierSecurity = security.UnderlierSecurity;

                // _context.Entry(security).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            else
            {
                return NotFound();
            }
            existingSecurity = _context.Security.Where(s => s.Sid == Sid)
                                                   .FirstOrDefault<Security>();//added last
            return Ok(existingSecurity);
        }

        [HttpPost("Create-New-Security")]
        public async Task<ActionResult<Security>> PostNewSecurity([FromBody] Security json)
        {
            /*
            string x = Convert.ToString(json);
            if (_context.Security == null)
            {
                return Problem("Error");
            }

            Security s = JsonSerializer.Deserialize<Security>(x);*/
            if (json is Security)
            {
                _context.Security.Add(json);
                await _context.SaveChangesAsync();
            }
            else if (json is Option)
            {
                _context.Option.Add(json as Option);
                await _context.SaveChangesAsync();
            }
          // return CreatedAtAction("GetSecurity", new { id = json.Sid }, json);
            return Ok();
        }

        private bool SecurityExists(int id)
        {
            return (_context.Security?.Any(e => e.Sid == id)).GetValueOrDefault();
        }
    }
}
