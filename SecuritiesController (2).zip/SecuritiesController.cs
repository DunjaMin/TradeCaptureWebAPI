﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using TradeCaptureWebAPI.Models;

namespace TradeCaptureWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SecuritiesController : ControllerBase
    {
        private readonly TradeCaptureContext _context;

        public SecuritiesController(TradeCaptureContext context)
        {
            _context = context;
        }

        [HttpGet("Get-By-Sid/{Sid}")]
        public async Task<ActionResult<Security>> GetSecurity(int Sid)
        {
            if (_context.Security == null)
            {
                return NotFound();
            }
            var security = await _context.Security.FindAsync(Sid);

            if (security == null)
            {
                return NotFound();
            }
            return security;
        }

        [HttpPut("Update-By-Sid/{Sid}")]
        public async Task<IActionResult> PutSecurity(int Sid, [FromBody] Security security)
        {
            var existingSecurity = _context.Security.Where(s => s.Sid == Sid)
                                                   .FirstOrDefault<Security>();

            if (existingSecurity != null)
            {
                existingSecurity.TypeId = security.TypeId;
                existingSecurity.Name = security.Name;
                existingSecurity.StartDate = security.StartDate;
                existingSecurity.EndDate = security.EndDate;
                existingSecurity.Ticker = security.Ticker;
                existingSecurity.ExchangeId = security.ExchangeId;
                existingSecurity.CurrencyId = security.CurrencyId;
                existingSecurity.UnderlierSecurity = security.UnderlierSecurity;

                // _context.Entry(security).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            else
            {
                return NotFound();
            }
            existingSecurity = _context.Security.Where(s => s.Sid == Sid)
                                                   .FirstOrDefault();//added last
            return Ok(existingSecurity);
        }

        [HttpPost("Create-New-Security")]
        public async Task<ActionResult<Security>> PostNewSecurity([FromBody] Security json)
        {
            
            string resoult = JsonConvert.SerializeObject(json,Formatting.Indented, new CustomConverter(typeof(Security)));
            Console.WriteLine(resoult);

            if (resoult == null) {
                return null;
            }

            var newResoult = JsonConvert.DeserializeObject<Security>(value:resoult, new CustomConverter(typeof(Security)));

            _context.Security.Add(newResoult);
            await _context.SaveChangesAsync();

          /*    _context.Security.Add(newSecurity);
              await _context.SaveChangesAsync();

              var max = _context.Security.Max(p => p.Sid);
              var security = _context.Security.Where(s => s.Sid == max)
                                                     .FirstOrDefault();*/
            
            /*  if (json is Security)
              {
                  _context.Security.Add(json);
                  await _context.SaveChangesAsync();
              }
              else if (json is Option)
              {
                  _context.Option.Add(json as Option);
                  await _context.SaveChangesAsync();
              }

              var max = _context.Security.Max(p => p.Sid);
              var security = _context.Security.Where(s => s.Sid == max)
                                                     .FirstOrDefault();

              if (security == null)
              {
                  return NotFound();
              }

              return Ok(security);*/
             return Ok(newResoult);
            
        }

        private bool SecurityExists(int id)
        {
            return (_context.Security?.Any(e => e.Sid == id)).GetValueOrDefault();
        }
    }
}
